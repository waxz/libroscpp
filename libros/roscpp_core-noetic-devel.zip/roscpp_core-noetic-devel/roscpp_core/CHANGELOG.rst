^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package roscpp_core
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.3 (2023-06-15)
------------------
* Changed maintainer to Martin Pecka
* Contributors: Martin Pecka
